export class l{
  constructor(
    public email_id:string,
    public password:string,
    public user_name?:string,
    public mobileno?:string,
    public city?:string,
    public gender?:string,
    public address?:string
  ){

  }
}
